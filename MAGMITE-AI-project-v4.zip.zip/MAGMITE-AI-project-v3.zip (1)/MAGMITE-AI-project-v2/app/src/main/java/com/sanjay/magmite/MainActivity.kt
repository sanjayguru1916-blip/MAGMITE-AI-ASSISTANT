package com.sanjay.magmite

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                100
            )
        }

        setContent {
            MagmiteScreen()
        }
    }
}

@Composable
fun MagmiteScreen() {
    var status by remember { mutableStateOf("READY FOR COMMAND") }
    val context = LocalContext.current

    val infinite = rememberInfiniteTransition(label = "core")

    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(9000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 1300,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status = "VOICE RECOGNITION NOT AVAILABLE"
            return
        }

        val speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        speechRecognizer.setRecognitionListener(object : RecognitionListener {

            override fun onReadyForSpeech(params: Bundle?) {
                status = "LISTENING..."
            }

            override fun onBeginningOfSpeech() {
                status = "SPEAK NOW..."
            }

            override fun onRmsChanged(rmsdB: Float) {}

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                status = "PROCESSING..."
            }

            override fun onError(error: Int) {
                status = "TRY AGAIN"
                speechRecognizer.destroy()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )

                val command = matches?.firstOrNull()?.lowercase() ?: ""

status = when {
    command.contains("hello") || command.contains("hi magmite") ->
        "HELLO SANJAY! MAGMITE CORE ONLINE."

    command.contains("how are you") ->
        "ALL SYSTEMS ARE OPERATING NORMALLY."

    command.contains("your name") || command.contains("who are you") ->
        "I AM MAGMITE, YOUR AI ASSISTANT."

    command.contains("status") ->
        "ALL MAGMITE SYSTEMS ARE ONLINE."

    command.isNotEmpty() ->
        "COMMAND RECEIVED: ${command.uppercase()}"

    else ->
        "NO COMMAND DETECTED"
}

                speechRecognizer.destroy()
            }

            override fun onPartialResults(partialResults: Bundle?) {}

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MAGMITE")
        }

        speechRecognizer.startListening(intent)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(28.dp))

            Text(
                "MAGMITE",
                color = Color(0xFFFF5A1F),
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 5.sp
            )

            Text(
                "AI CORE // ONLINE",
                color = Color(0xFF9A9A9A),
                fontSize = 11.sp,
                letterSpacing = 2.sp
            )

            Spacer(Modifier.height(36.dp))

            Box(
                modifier = Modifier.size(250.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(rotation)
                ) {
                    val c = center

                    drawCircle(Color(0x33FF4A00), 105.dp.toPx(), c)
                    drawCircle(
                        Color(0xFFFF4A00),
                        92.dp.toPx(),
                        c,
                        style = Stroke(2.dp.toPx())
                    )
                    drawCircle(
                        Color(0x66FFB000),
                        75.dp.toPx(),
                        c,
                        style = Stroke(3.dp.toPx())
                    )

                    drawLine(
                        Color(0xFFFF5A1F),
                        Offset(c.x - 115.dp.toPx(), c.y),
                        Offset(c.x - 80.dp.toPx(), c.y),
                        3.dp.toPx()
                    )

                    drawLine(
                        Color(0xFFFF5A1F),
                        Offset(c.x + 80.dp.toPx(), c.y),
                        Offset(c.x + 115.dp.toPx(), c.y),
                        3.dp.toPx()
                    )
                }

                Box(
                    modifier = Modifier
                        .size((92 * pulse).dp)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFFFFC04D),
                                    Color(0xFFFF4A00),
                                    Color(0xFF350800)
                                )
                            ),
                            CircleShape
                        )
                        .border(
                            2.dp,
                            Color(0xFFFFB000),
                            CircleShape
                        )
                )
            }

            Spacer(Modifier.height(28.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Color(0xFF4A2619),
                        RoundedCornerShape(14.dp)
                    )
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        "SYSTEM STATUS",
                        color = Color(0xFFFF5A1F),
                        fontSize = 11.sp,
                        letterSpacing = 2.sp
                    )

                    Spacer(Modifier.height(8.dp))

                    Text(
                        status,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        "MAGMITE intelligence core is active.",
                        color = Color(0xFF8A8A8A),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(68.dp)
                    .border(
                        1.dp,
                        Color(0xFFFF5A1F),
                        RoundedCornerShape(18.dp)
                    )
                    .clickable {
                        status = "STARTING VOICE CORE..."
                        startListening()
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "◉   TAP TO SPEAK",
                    color = Color(0xFFFF7A38),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    letterSpacing = 2.sp
                )
            }

            Spacer(Modifier.height(18.dp))
        }
    }
}