package com.sanjay.magmite

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
        setContent { MagmiteScreen() }
    }
}

@Composable
fun MagmiteScreen() {
    var status by remember { mutableStateOf("STANDBY • SAY HEY MAGMITE") }
    var isListening by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val infinite = rememberInfiniteTransition(label = "magmite_hud")

    val rotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 2500 else 12000, easing = LinearEasing)
        ), label = "rotation"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.92f, targetValue = if (isListening) 1.15f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 550 else 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "pulse"
    )

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            status = "VOICE SERVICE NOT AVAILABLE"
            isListening = false
            return
        }
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true; status = "LISTENING • SPEAK NOW" }
            override fun onBeginningOfSpeech() { status = "I'M LISTENING..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false; status = "PROCESSING COMMAND..." }
            override fun onError(error: Int) {
                isListening = false
                status = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "NO COMMAND DETECTED"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "VOICE TIMEOUT • TRY AGAIN"
                    else -> "TRY AGAIN"
                }
                recognizer.destroy()
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val command = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.lowercase().orEmpty()
                status = when {
                    command.contains("hey magmite") || command.contains("hi magmite") || command.contains("hello magmite") -> "HELLO SANJAY • MAGMITE ONLINE"
                    command.contains("how are you") -> "ALL SYSTEMS OPERATING NORMALLY"
                    command.contains("who are you") || command.contains("your name") -> "I AM MAGMITE • YOUR AI ASSISTANT"
                    command.contains("status") -> "CORE STATUS • ALL SYSTEMS ONLINE"
                    command.isNotEmpty() -> "COMMAND: ${command.uppercase()}"
                    else -> "NO COMMAND DETECTED"
                }
                recognizer.destroy()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MAGMITE")
        }
        recognizer.startListening(intent)
    }

    val background = Color(0xFF050912)
    val cyan = Color(0xFF21D9FF)

    Box(Modifier.fillMaxSize().background(background).padding(24.dp)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MAGMITE", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp)
                    Spacer(Modifier.height(3.dp))
                    Text("PERSONAL AI ASSISTANT", color = Color(0xFF8D99A8), fontSize = 9.sp, letterSpacing = 2.sp)
                }
                OnlineBadge()
            }
            Spacer(Modifier.height(55.dp))
            Box(Modifier.size(310.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize().rotate(rotation)) {
                    val c = center
                    drawCircle(cyan.copy(alpha = 0.08f), 145.dp.toPx(), c)
                    drawCircle(cyan.copy(alpha = 0.20f), 135.dp.toPx(), c, style = Stroke(1.dp.toPx()))
                    drawCircle(cyan.copy(alpha = 0.65f), 112.dp.toPx(), c, style = Stroke(2.dp.toPx()))
                    drawCircle(cyan.copy(alpha = 0.25f), 92.dp.toPx(), c, style = Stroke(1.dp.toPx()))
                    drawArc(cyan, -40f, 80f, false, Offset(c.x - 140.dp.toPx(), c.y - 140.dp.toPx()), Size(280.dp.toPx(), 280.dp.toPx()), style = Stroke(4.dp.toPx()))
                    drawArc(Color(0xFFB99CFF), 140f, 65f, false, Offset(c.x - 140.dp.toPx(), c.y - 140.dp.toPx()), Size(280.dp.toPx(), 280.dp.toPx()), style = Stroke(4.dp.toPx()))
                    drawLine(cyan, Offset(c.x - 150.dp.toPx(), c.y), Offset(c.x - 120.dp.toPx(), c.y), 2.dp.toPx())
                    drawLine(cyan, Offset(c.x + 120.dp.toPx(), c.y), Offset(c.x + 150.dp.toPx(), c.y), 2.dp.toPx())
                }
                Box(
                    Modifier.size((125 * pulse).dp)
                        .background(Brush.radialGradient(listOf(Color(0xFFE9FBFF), Color(0xFF35CFFF), Color(0xFF0877AA), Color(0xFF07121F))), CircleShape)
                        .border(3.dp, Color(0xFFBDF5FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("M", color = Color.White, fontSize = 58.sp, fontWeight = FontWeight.Black) }
            }
            Spacer(Modifier.height(22.dp))
            Text("MAGMITE CORE", color = cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(10.dp))
            Text(status, color = Color(0xFFD6E0EA), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudChip("VOICE", if (isListening) "LISTENING" else "READY", Modifier.weight(1f))
                HudChip("CORE", "ACTIVE", Modifier.weight(1f))
                HudChip("MODE", "HUD", Modifier.weight(1f))
            }
            Spacer(Modifier.height(18.dp))
            Box(
                Modifier.fillMaxWidth().height(78.dp).background(Color(0xFF0B1621), RoundedCornerShape(25.dp))
                    .border(1.5.dp, cyan.copy(alpha = 0.65f), RoundedCornerShape(25.dp))
                    .clickable { if (!isListening) { status = "STARTING VOICE CORE..."; startListening() } },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(if (isListening) 16.dp else 12.dp).background(if (isListening) Color(0xFFB99CFF) else cyan, CircleShape))
                    Spacer(Modifier.width(14.dp))
                    Text(if (isListening) "LISTENING..." else "TAP TO SPEAK", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun OnlineBadge() {
    Row(
        Modifier.background(Color(0xFF0B1621), RoundedCornerShape(22.dp))
            .border(1.dp, Color(0xFF29445A), RoundedCornerShape(22.dp)).padding(horizontal = 13.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("●", color = Color(0xFF32E6FF), fontSize = 11.sp)
        Spacer(Modifier.width(6.dp))
        Text("ONLINE", color = Color(0xFF7CE7FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HudChip(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.height(65.dp).background(Color(0xFF0B141E), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF1D3344), RoundedCornerShape(16.dp)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color(0xFF71808E), fontSize = 8.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(5.dp))
        Text(value, color = Color(0xFF8DEBFF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}
