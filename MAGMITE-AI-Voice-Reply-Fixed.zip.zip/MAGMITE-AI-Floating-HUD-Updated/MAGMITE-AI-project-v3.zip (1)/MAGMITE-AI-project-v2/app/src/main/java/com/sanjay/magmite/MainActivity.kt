package com.sanjay.magmite

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {
override fun onCreate(savedInstanceState: Bundle?) {
super.onCreate(savedInstanceState)

    if (ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) != PackageManager.PERMISSION_GRANTED
    ) {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.RECORD_AUDIO),
            100
        )
    }

    setContent {
        MagmiteScreen()
    }
}

}

@Composable
fun MagmiteScreen() {
var status by remember {
mutableStateOf("STANDBY • SAY HEY MAGMITE")
}

val context = LocalContext.current

// MAGMITE Voice Engine
var textToSpeech by remember {
    mutableStateOf<TextToSpeech?>(null)
}

var ttsReady by remember {
    mutableStateOf(false)
}

DisposableEffect(context) {
    lateinit var engine: TextToSpeech

    engine = TextToSpeech(context.applicationContext) { result ->
        if (result == TextToSpeech.SUCCESS) {
            engine.language = Locale.US
            ttsReady = true
        }
    }

    textToSpeech = engine

    onDispose {
        engine.stop()
        engine.shutdown()
    }
}

// Local voice reply - Gemini API not required
fun replyWithVoice(message: String) {
    status = message.uppercase()

    if (ttsReady) {
        textToSpeech?.speak(
            message,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "MAGMITE_REPLY"
        )
    }
}

val infinite = rememberInfiniteTransition(label = "hud")

val rotation by infinite.animateFloat(
    0f,
    360f,
    infiniteRepeatable(
        tween(14000, easing = LinearEasing)
    ),
    label = "rotation"
)

val pulse by infinite.animateFloat(
    0.92f,
    1.08f,
    infiniteRepeatable(
        tween(1200, easing = FastOutSlowInEasing),
        RepeatMode.Reverse
    ),
    label = "pulse"
)

fun startListening() {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
        status = "VOICE SERVICE NOT AVAILABLE"
        return
    }

    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)

    recognizer.setRecognitionListener(object : RecognitionListener {

        override fun onReadyForSpeech(params: Bundle?) {
            status = "LISTENING..."
        }

        override fun onBeginningOfSpeech() {
            status = "I'M LISTENING"
        }

        override fun onRmsChanged(rmsdB: Float) {}

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            status = "PROCESSING COMMAND..."
        }

        override fun onError(error: Int) {
            status = "TRY AGAIN"
            recognizer.destroy()
        }

        override fun onResults(results: Bundle?) {

            val command = results
                ?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )
                ?.firstOrNull()
                ?.lowercase()
                .orEmpty()

            when {

                command.contains("hey magmite") ||
                command.contains("hi magmite") ||
                command.contains("hello magmite") -> {

                    replyWithVoice(
                        "Hello Sanjay. MAGMITE online. How can I help you?"
                    )
                }

                command.contains("how are you") -> {

                    replyWithVoice(
                        "All systems operating normally."
                    )
                }

                command.contains("your name") ||
                command.contains("who are you") -> {

                    replyWithVoice(
                        "I am MAGMITE, your personal AI assistant."
                    )
                }

                command.contains("status") -> {

                    replyWithVoice(
                        "Core status. All systems online."
                    )
                }

                command.isNotEmpty() -> {
                    status = "COMMAND: ${command.uppercase()}"
                }

                else -> {
                    status = "NO COMMAND DETECTED"
                }
            }

            recognizer.destroy()
        }

        override fun onPartialResults(
            partialResults: Bundle?
        ) {}

        override fun onEvent(
            eventType: Int,
            params: Bundle?
        ) {}
    })

    val intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {

            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )

            putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "Speak to MAGMITE"
            )
        }

    recognizer.startListening(intent)
}

Box(
    modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF070A10))
        .padding(20.dp)
) {

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement =
                Arrangement.SpaceBetween,
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Column {

                Text(
                    "MAGMITE",
                    color = Color.White,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp
                )

                Text(
                    "PERSONAL AI ASSISTANT",
                    color = Color(0xFF8D99A8),
                    fontSize = 9.sp,
                    letterSpacing = 2.sp
                )
            }

            Box(
                modifier = Modifier
                    .background(
                        Color(0xFF101923),
                        RoundedCornerShape(20.dp)
                    )
                    .border(
                        1.dp,
                        Color(0xFF26384A),
                        RoundedCornerShape(20.dp)
                    )
                    .padding(
                        horizontal = 12.dp,
                        vertical = 7.dp
                    )
            ) {

                Text(
                    "●  ONLINE",
                    color = Color(0xFF7CE7FF),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(Modifier.height(40.dp))

        Box(
            modifier = Modifier.size(260.dp),
            contentAlignment = Alignment.Center
        ) {

            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(rotation)
            ) {

                val c = center
                val cyan = Color(0xFF61D8FF)

                drawCircle(
                    Color(0x1026B9FF),
                    116.dp.toPx(),
                    c
                )

                drawCircle(
                    cyan.copy(alpha = 0.18f),
                    105.dp.toPx(),
                    c,
                    style = Stroke(1.dp.toPx())
                )

                drawCircle(
                    cyan.copy(alpha = 0.65f),
                    91.dp.toPx(),
                    c,
                    style = Stroke(2.dp.toPx())
                )

                drawArc(
                    cyan,
                    -35f,
                    70f,
                    false,
                    Offset(
                        c.x - 112.dp.toPx(),
                        c.y - 112.dp.toPx()
                    ),
                    androidx.compose.ui.geometry.Size(
                        224.dp.toPx(),
                        224.dp.toPx()
                    ),
                    style = Stroke(3.dp.toPx())
                )

                drawArc(
                    Color(0xFFB49CFF),
                    145f,
                    60f,
                    false,
                    Offset(
                        c.x - 112.dp.toPx(),
                        c.y - 112.dp.toPx()
                    ),
                    androidx.compose.ui.geometry.Size(
                        224.dp.toPx(),
                        224.dp.toPx()
                    ),
                    style = Stroke(3.dp.toPx())
                )

                drawLine(
                    cyan,
                    Offset(
                        c.x - 125.dp.toPx(),
                        c.y
                    ),
                    Offset(
                        c.x - 100.dp.toPx(),
                        c.y
                    ),
                    2.dp.toPx()
                )

                drawLine(
                    cyan,
                    Offset(
                        c.x + 100.dp.toPx(),
                        c.y
                    ),
                    Offset(
                        c.x + 125.dp.toPx(),
                        c.y
                    ),
                    2.dp.toPx()
                )
            }

            Box(
                modifier = Modifier
                    .size((104 * pulse).dp)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color(0xFFE7FAFF),
                                Color(0xFF45C9FF),
                                Color(0xFF123C70)
                            )
                        ),
                        CircleShape
                    )
                    .border(
                        2.dp,
                        Color(0xFFB5F2FF),
                        CircleShape
                    )
            )

            Text(
                "M",
                color = Color.White,
                fontSize = 42.sp,
                fontWeight = FontWeight.Black
            )
        }

        Spacer(Modifier.height(25.dp))

        Text(
            "MAGMITE CORE",
            color = Color(0xFF7CE7FF),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 3.sp
        )

        Spacer(Modifier.height(8.dp))

        Text(
            status,
            color = Color(0xFFD6E0EA),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.weight(1f))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement =
                Arrangement.spacedBy(10.dp)
        ) {

            HudChip(
                "VOICE",
                "READY",
                Modifier.weight(1f)
            )

            HudChip(
                "CORE",
                "ACTIVE",
                Modifier.weight(1f)
            )

            HudChip(
                "MODE",
                "HUD",
                Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(70.dp)
                .background(
                    Color(0xFF101923),
                    RoundedCornerShape(22.dp)
                )
                .border(
                    1.dp,
                    Color(0xFF3A637A),
                    RoundedCornerShape(22.dp)
                )
                .clickable {
                    status = "STARTING VOICE CORE..."
                    startListening()
                },
            contentAlignment = Alignment.Center
        ) {

            Row(
                verticalAlignment =
                    Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier
                        .size(13.dp)
                        .background(
                            Color(0xFF6EE7FF),
                            CircleShape
                        )
                )

                Spacer(Modifier.width(12.dp))

                Text(
                    "TAP TO SPEAK",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }

        Spacer(Modifier.height(8.dp))
    }
}

}

@Composable
private fun HudChip(
title: String,
value: String,
modifier: Modifier = Modifier
) {

Column(
    modifier = modifier
        .background(
            Color(0xFF0D141D),
            RoundedCornerShape(14.dp)
        )
        .border(
            1.dp,
            Color(0xFF1F3040),
            RoundedCornerShape(14.dp)
        )
        .padding(vertical = 10.dp),
    horizontalAlignment =
        Alignment.CenterHorizontally
) {

    Text(
        title,
        color = Color(0xFF71808E),
        fontSize = 8.sp,
        letterSpacing = 1.sp
    )

    Text(
        value,
        color = Color(0xFF8DEBFF),
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold
    )
}

}